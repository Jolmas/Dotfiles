#!/bin/bash
#       ╭───╮╭───╮╭───╮╭───╮╭───╮╭───╮
#  WOFI │ R ││ A ││ D ││ I ││ O ││ N │
#       ╰───╯╰───╯╰───╯╰───╯╰───╯╰───╯
# A bash script written by Christos Angelopoulos, October 2023, under GPL v2
# Modified for Wofi by Jolmasch, August 2025

function random_station
{
    rand_max_lim=$(grep -v -E '^$|^//' "$1" | wc -l)
    rand_station_index=$((1 + RANDOM % rand_max_lim))
    STATION=$(grep -v -E '^$|^//' "$1" | head -"$rand_station_index" | tail -1 | awk '{print $2}' | sed 's/-/ /g;s/~//g')
    STATION_URL="$(grep "~${STATION// /-}"~ "$1" | awk '{print $1}')"
}

function play_station
{
    echo "STATION: $STATION"
    echo "URL     : $STATION_URL"
    pkill mpv
    mpv "$STATION_URL"
    sleep 10
    pkill wofi
}

function select_tag
{
    TAGS=$(sed 's/ /\n/g' "$HOME/.config/radion/stations.txt" | grep '#' | grep -v '#Favorites' | sort | uniq | sed 's/#//g')
    FAVS=$(grep '#Favorites' "$HOME/.config/radion/stations.txt" | grep -v -E '^$|^//' | awk {'print $2'} | sed 's/~//g;s/-/ /g')

    OPTIONS="Random Station\n"
    if [ -n "$FAVS" ]; then
        OPTIONS+="--- Favorites ---\n$FAVS\n"
    fi
    if [ -n "$TAGS" ]; then
        OPTIONS+="--- Tags ---\n$TAGS\n"
    fi
    OPTIONS+="--- Actions ---\nAll Stations\nEdit Stations\nRandom Station\nStop Radio\nPreferences\nSearch Stations\nQuit"

    SELECTION=$(echo -e "$OPTIONS" | wofi --show dmenu -p "Radion:")

    case "$SELECTION" in
        "All Stations")
            select_station_from_file "$HOME/.config/radion/stations.txt" "All Stations"
            ;;
        "Edit Stations")
            eval "$(grep 'Preferred_editor' "$HOME/.config/radion/radion.conf" | sed 's/Preferred_editor//')" "$HOME/.config/radion/stations.txt"
            ;;
        "Random Station")
            random_station "$HOME/.config/radion/stations.txt"
            play_station
            ;;
        "Stop Radio")
        	pkill mpv
        	;;
        "Preferences")
            eval "$(grep 'Preferred_editor' "$HOME/.config/radion/radion.conf" | sed 's/Preferred_editor//')" "$HOME/.config/radion/radion.conf"
            ;;
        "Search Stations")
            URL_OPENER="xdg-open"
            if [[ "$OSTYPE" == "darwin"* ]]; then URL_OPENER="open"; fi
            $URL_OPENER "https://www.radio-browser.info/tags"
            echo "Press Enter to continue with radion."
            read -r
            ;;
        "Quit")
        	exit 0
            ;;
        "---"*)
            # Ignore separator lines
            ;;
        *)
            # Verify if selection is a favorite station
             if grep -q "~${SELECTION// /-}"~ "$HOME/.config/radion/stations.txt"; then
                STATION="$SELECTION"
                STATION_URL="$(grep "~${STATION// /-}"~ "$HOME/.config/radion/stations.txt" | awk '{print $1}')"
                play_station
            # Verificar si la selección es una etiqueta
            elif grep -q "#$SELECTION" "$HOME/.config/radion/stations.txt"; then
                select_station_from_file <(grep "#$SELECTION" "$HOME/.config/radion/stations.txt") "$SELECTION"
            fi
            ;;
    esac
}

function select_station_from_file
{
    local FILE_PATH="$1"
    local PROMPT_TEXT="$2"
    local STATIONS=$(grep -v -E '^$|^//' "$FILE_PATH" | awk '{print $2}' | sed 's/~//g;s/-/ /g')
    
    local SELECTION=$(echo -e "Random Station\nBack\nQuit\n$STATIONS" | wofi --show dmenu -p "$PROMPT_TEXT:")

    case "$SELECTION" in
        "Random Station")
        	random_station "$FILE_PATH"
            play_station
            ;;
        "Back")
            # Return to Main Menu
            ;;
        "Quit")
            exit 0
            ;;
        *)
            if [ -n "$SELECTION" ]; then
                STATION="$SELECTION"
                STATION_URL="$(grep "~${STATION// /-}"~ "$FILE_PATH" | awk '{print $1}')"
                play_station
            fi
            ;;
    esac
}

# --- Main Logic ---

while true; do
    select_tag
done
